SISTEM INFORMASI WARUNG SEAFOOD BAHARI

Cara membuka di Visual Studio Code:
1. Ekstrak file ZIP ini terlebih dahulu.
2. Buka Visual Studio Code.
3. Pilih File > Open Folder, lalu pilih folder Seafood_Bahari_Project.
4. Buka file index.html.
5. Untuk menjalankan, klik kanan index.html lalu pilih Open with Live Server (jika ekstensi Live Server sudah terpasang), atau buka index.html langsung di browser.

Catatan:
- Aplikasi ini menggunakan HTML, Tailwind CSS CDN, JavaScript, dan localStorage.
- Koneksi internet diperlukan agar Tailwind CSS CDN dapat dimuat.
- Data disimpan di browser yang digunakan melalui localStorage, bukan database server.
